
from PyQt5 import QtCore, QtGui, QtWidgets
from model_conclusion_class import Model_Conclusion

import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import pyqtSlot
import os
import sub_windows

class Ui_GOOG_GUI(object):
    def open_detail_window(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = sub_windows.Detail_Results()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def setupUi(self, GOOG_GUI):
        self.cwd = os.getcwd() 
        GOOG_GUI.setObjectName("GOOG_GUI")
        self.scroll_hight = 661
        self.scroll_width = 581
        GOOG_GUI.resize(702, 657)
        GOOG_GUI.setToolTipDuration(-1)
        GOOG_GUI.setStyleSheet("\n"
"background-color: rgb(0, 0, 0);")
        
        self.scrollArea = QtWidgets.QScrollArea(GOOG_GUI)
        self.scrollArea.setGeometry(QtCore.QRect(20, 60, self.scroll_hight, self.scroll_width))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtWidgets.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 659, 579))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        
        self.label_Image = QLabel(self.scrollArea)
        
        self.wiget_logo = QtWidgets.QWidget(GOOG_GUI)
        self.wiget_logo.setGeometry(QtCore.QRect(460, 10, 221, 41))
        self.wiget_logo.setObjectName("MSFE")
        self.label_Image = QLabel(self.wiget_logo)
        self.image = QtGui.QImage(QtGui.QImageReader(self.cwd + '/Images/msfe.png').read())
        self.image = self.image.scaled(221, 41, aspectRatioMode=QtCore.Qt.KeepAspectRatio, transformMode=QtCore.Qt.SmoothTransformation) # To scale image for example and keep its Aspect Ration    
        self.label_Image.setPixmap(QtGui.QPixmap(self.image))
        
        '''
        #self.image_profile = QPixmap(self.cwd + '/MainResult.png')
        self.image = QtGui.QImage(QtGui.QImageReader(self.cwd + '/MainResult.png').read())
        self.image = self.image.scaled(self.scroll_hight,self.scroll_width, aspectRatioMode=QtCore.Qt.KeepAspectRatio, transformMode=QtCore.Qt.SmoothTransformation) # To scale image for example and keep its Aspect Ration    
        
        #self.label_Image.setPixmap(self.image_profile) 
        self.label_Image.setPixmap(QtGui.QPixmap(self.image))
        '''
        
        self.widget = QtWidgets.QWidget(GOOG_GUI)
        #self.widget.setGeometry(QtCore.QRect(460, 10, 221, 41))
        self.widget.setGeometry(QtCore.QRect(20, 60, self.scroll_hight, self.scroll_width))
        self.widget.setObjectName("MSFE")
        self.label_Image = QLabel(self.widget)
        self.image = QtGui.QImage(QtGui.QImageReader(self.cwd + '/Images/black.png').read())
        #self.image = self.image.scaled(221, 41, aspectRatioMode=QtCore.Qt.KeepAspectRatio, transformMode=QtCore.Qt.SmoothTransformation) # To scale image for example and keep its Aspect Ration    
        self.image = self.image.scaled(self.scroll_hight, self.scroll_width)#, aspectRatioMode=QtCore.Qt.KeepAspectRatio, transformMode=QtCore.Qt.SmoothTransformation) # To scale image for example and keep its Aspect Ration    
        
        
        #self.label_Image.setPixmap(self.image_profile) 
        self.label_Image.setPixmap(QtGui.QPixmap(self.image))
        
        
        

        
        
        self.widget = QtWidgets.QWidget(GOOG_GUI)
        self.widget.setGeometry(QtCore.QRect(20, 20, 426, 27))
        self.widget.setObjectName("widget")
        
        
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        
        
        self.comboBox = QtWidgets.QComboBox(self.widget)
        self.comboBox.setStyleSheet("color: rgb(255, 255, 255);")
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.horizontalLayout_2.addWidget(self.comboBox)
        
        
        self.StartDate = QtWidgets.QDateEdit(self.widget)
        self.StartDate.setStyleSheet("color: rgb(255, 255, 255);")
        self.StartDate.setObjectName("StartDate")
        self.horizontalLayout_2.addWidget(self.StartDate)
        
        self.EndDate = QtWidgets.QDateEdit(self.widget)
        self.EndDate.setStyleSheet("color: rgb(255, 255, 255);")
        self.EndDate.setObjectName("EndDate")
        self.horizontalLayout_2.addWidget(self.EndDate)
        
        
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setStyleSheet("color: rgb(255, 255, 255);\n"
"selection-color: rgb(144, 144, 144);")
        self.pushButton_2.setObjectName("RUN")
        self.pushButton_2.clicked.connect(self.plot_main_result)
        
        self.horizontalLayout_2.addWidget(self.pushButton_2)
        self.pushButton_3 = QtWidgets.QPushButton(self.widget)
        self.pushButton_3.setStyleSheet("color: rgb(255, 255, 255);\n"
"selection-color: rgb(144, 144, 144);")
        self.pushButton_3.setObjectName("Details")
        self.pushButton_3.clicked.connect(self.open_detail_window)
        
        self.horizontalLayout_2.addWidget(self.pushButton_3)
        self.horizontalLayout.addLayout(self.horizontalLayout_2)

        self.retranslateUi(GOOG_GUI)
        QtCore.QMetaObject.connectSlotsByName(GOOG_GUI)

    def plot_main_result(self):
        
       #label_Image.setScaledContents(True);
        #self.image_profile = QPixmap(self.cwd + '/MainResult.png')
        self.image = QtGui.QImage(QtGui.QImageReader(self.cwd + '/Images/MainResult.png').read())
        self.image = self.image.scaled(self.scroll_hight,self.scroll_width, aspectRatioMode=QtCore.Qt.KeepAspectRatio, transformMode=QtCore.Qt.SmoothTransformation)
        #self.label_Image.setPixmap(self.image_profile) 
        self.label_Image.setPixmap(QtGui.QPixmap(self.image))
        #self.label_Image.setPixmap(QtGui.QPixmap(self.cwd + '/MainResult.png'))
    

    def retranslateUi(self, GOOG_GUI):
        _translate = QtCore.QCoreApplication.translate
        GOOG_GUI.setWindowTitle(_translate("GOOG_GUI", "Dialog"))
        self.comboBox.setItemText(0, _translate("GOOG_GUI", "Corn"))
        self.comboBox.setItemText(1, _translate("GOOG_GUI", "Soybean"))
        self.comboBox.setItemText(2, _translate("GOOG_GUI", "Wheat"))
        self.comboBox.setItemText(3, _translate("GOOG_GUI", "Potato"))
        self.pushButton_2.setText(_translate("GOOG_GUI", "RUN"))
        self.pushButton_3.setText(_translate("GOOG_GUI", "Details"))


    '''
    Result = Model_Conclusion()
    Result.Run_models()
    Main_result = Result.Results()
    Main_result.show()
    
    detail_graph = Result.AccuracyStdGraph()
    detail_graph = Result.HeatMapGraph()
    detail_graph.savefig('HeatMap.png', bbox_inches='tight')
    detail_graph = Result.TimeLagAnalysis()
    detail_graph.savefig('TimeLagAnalysis.png', bbox_inches='tight')
    '''
