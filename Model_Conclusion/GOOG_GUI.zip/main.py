# -*- coding: utf-8 -*-
"""
Created on Thu Nov 16 04:56:34 2017

@author: juna
"""
import sys
from model_conclusion_class import Model_Conclusion

from PyQt5.QtCore import Qt
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QGridLayout, QLabel, QLineEdit
from PyQt5.QtWidgets import QTextEdit, QWidget, QDialog, QApplication

import Gui_script

class MainWindow(QDialog, Gui_script.Ui_GOOG_GUI):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

if __name__ == '__main__':
    
    #Result = Model_Conclusion()
    #Result.Run_models()
    #Main_result = Result.Results()
    #Main_result.show()
    
    #detail_graph = Result.AccuracyStdGraph()
    #detail_graph = Result.HeatMapGraph()
    #detail_graph.savefig('HeatMap.png', bbox_inches='tight')
    #detail_graph = Result.TimeLagAnalysis()
    #detail_graph.savefig('TimeLagAnalysis.png', bbox_inches='tight')
    
    app = QApplication(sys.argv)

    form = MainWindow()
    form.show()

    app.exec_()
